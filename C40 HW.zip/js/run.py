import tkinter as tk
import subprocess

# Create the main window
window = tk.Tk()
window.title("PowerShell Script Runner")

# Function to run PowerShell script as administrator and display its output
def run_powershell_script(script_path):
    try:
        powershell_command = f"Start-Process 'powershell.exe' -ArgumentList '-ExecutionPolicy Bypass -File \"{script_path}\"' -Verb RunAs"
        subprocess.run(["powershell.exe", "-Command", powershell_command], shell=True)
    except subprocess.CalledProcessError as e:
        output_text.config(state=tk.NORMAL)
        output_text.delete(1.0, tk.END)
        output_text.insert(tk.END, f"Error: {e}\n")
        output_text.config(state=tk.DISABLED)

def check_apache_status():
    try:
        result = subprocess.run(["sc", "query", "Apache2.4"], capture_output=True, text=True, check=True)
        if "RUNNING" in result.stdout:
            return "Apache 2.4 is running."
        else:
            return "Apache 2.4 is not running."
    except subprocess.CalledProcessError:
        return "Error: Unable to determine Apache status."

def update_status_label():
    status = check_apache_status()
    status_label.config(text=f"Apache Status: {status}")
    window.after(5000, update_status_label)  # Update every 5 seconds

# Create buttons
button1 = tk.Button(window, text="Start", command=lambda: run_powershell_script("C:/Users/user/Desktop/Start.ps1"))
button2 = tk.Button(window, text="Close", command=lambda: run_powershell_script("C:/Users/user/Desktop/Close.ps1"))
button3 = tk.Button(window, text="Restart", command=lambda: run_powershell_script("C:/Users/user/Desktop/Restart.ps1"))
button4 = tk.Button(window, text="Check config syntax", command=lambda: run_powershell_script("C:/Users/user/Desktop/chsyn.ps1"))

# Create labels
status_label = tk.Label(window, text="Apache Status: Checking...")
output_text = tk.Text(window, height=10, width=40)
output_text.config(state=tk.DISABLED)

# Arrange widgets using grid layout
status_label.grid(row=0, column=0, columnspan=2, padx=10, pady=10)
button1.grid(row=1, column=0, padx=10, pady=10)
button2.grid(row=1, column=1, padx=10, pady=10)
button3.grid(row=2, column=0, padx=10, pady=10)
button4.grid(row=2, column=1, padx=10, pady=10)
output_text.grid(row=3, columnspan=2, padx=10, pady=10)

# Start updating the status label in the background
window.after(0, update_status_label)  # Start updating immediately

# Start the GUI event loop
window.mainloop()
